/* 星际探索局 · 太阳系相对论飞行页 —— 主程序
 *
 * 【渲染管线】每帧三步，缺一不可：
 *   1. Sky pass    ：星空点云 → 立方体贴图。立方体相机必须放在**原点**并只复制
 *                    主相机的旋转——星星是无限远的，若跟着相机平移就会被"穿过去"。
 *   2. Scene pass  ：行星 + 轨道线 → 屏幕渲染目标。背景必须全透明，
 *                    以便在后处理里用 alpha 当遮罩合到星空上。
 *   3. 后处理       ：对每个屏幕像素**反解**源方向（逆光行差），采样立方体贴图，
 *                    施加多普勒调色，最后与 Scene pass 合成并做 ACES tone mapping。
 *
 * 【为什么必须用立方体贴图】β=0.98 时，屏幕四角像素反解出的源方向达 122.5°。
 * 用"加大 FOV 的前向视锥"根本覆盖不到（β=0.95 就需要 195° 视场，tan 会爆炸）。
 * 6 面立方体贴图恰好无缝覆盖整个球面（CubeCamera 内部固定 fov=90°），是唯一可行方案。
 *
 * 【为什么后处理必须做逆映射】光行差把星空朝运动方向压缩。若正向映射，
 * 屏幕边缘会采样到渲染从未覆盖的方向 → 黑边。逆映射则每个像素都能问出
 * "我该看向星空系的哪一点"，永不落空。
 *
 * 【相对论与渲染的分工】
 *   行星  —— 有限距离的实体，按相机真实位置渲染即正确，**不做光行差**
 *   星空  —— 无限远，只受方向影响，由后处理逐像素施加光行差
 *   太阳  —— 距离足够远，方向近似不变；但它本身在运动，故通过 sunViewDir
 *            把"朝太阳方向"变换到运动系，参与多普勒调色（横向多普勒）
 */

import { PLANETS } from '../planets.js';
import { ORBITS, SUN_RADIUS_KM, EARTH_RADIUS_KM, FOV_DEG, TIME_SCALE, solveKepler } from './solarsystem.js';
import {
  clampBeta, gamma as lorentzGamma, doppler, unaberrateCos, displayBetaAt,
  minTripSeconds, trueProfile, AU, C
} from './rel.js';

const THREE_CDN = 'https://cdn.jsdelivr.net/npm/three@0.160.1/build/three.module.js';
const STAR_COUNT = 8000;
const BAND_COUNT = 4000;
const CUBE_FACE = 1024;
const SKY_RADIUS = 500; // 世界单位。必须 < 相机的 far
const FLIGHT_DURATION = 20; // 秒。用于参数面板与调试

/**
 * 调试模式：?debug=xxx。用于逐段隔离渲染管线。
 *   nopost  跳过后期，直接显示主场景（行星 + 轨道线 + 太阳，背景为纯色）
 *   nosky   跳过星空立方体贴图（把星空当作纯黑）
 *   skyonly 只显示星空（跳过主场景）
 *   beta0   把 β 强制为 0（关闭光行差与多普勒）
 *   raw     关闭 ACES 曝光压缩，直接看线性值
 *   serial  每帧只渲染一个立方体面（排查面选择问题）
 */
const DEBUG = (() => {
  const q = new URLSearchParams(location.search).get('debug') || '';
  const flags = new Set(q.split(/[,+]/).filter(Boolean));
  return {
    nopost: flags.has('nopost'),
    nosky: flags.has('nosky'),
    skyonly: flags.has('skyonly'),
    beta0: flags.has('beta0'),
    raw: flags.has('raw'),
    serial: flags.has('serial'),
    any: flags.size > 0,
    label: [...flags].join(',')
  };
})();

const el = {
  gl: document.getElementById('gl'),
  labels: document.getElementById('labels'),
  selcard: document.getElementById('selcard'),
  selZh: document.getElementById('sel-zh'),
  selEn: document.getElementById('sel-en'),
  selTag: document.getElementById('sel-tag'),
  selLink: document.getElementById('sel-link'),
  hudBeta: document.getElementById('hud-beta'),
  hudGamma: document.getElementById('hud-gamma'),
  hudTau: document.getElementById('hud-tau'),
  hudDop: document.getElementById('hud-dop'),
  hudNote: document.getElementById('hud-note'),
  panel: document.getElementById('panel'),
  hint: document.getElementById('hint'),
  boot: document.getElementById('boot')
};

/* ============================================================
   运行时参数（面板可调；默认值与 solarsystem.js 中的常量一致）
   ============================================================ */
const P = {
  duration: 20,   // 一程飞行时长（秒，外部参考系）
  betaPeak: 0.98, // 显示用峰值 β（叙事参数）
  ED: 0.5,        // 距离幂指数
  ER: 0.45,       // 半径幂指数
  BASE: 0.006,    // 行星显示直径占视野高度的比例
  relativity: true
};

const DEF = 2 * Math.pow(1.52371, 0.5) * 1.35;  // 默认视野跨度（基准，决定行星世界尺寸）
const FULL = 2 * Math.pow(30.06992, 0.5) * 1.15; // 全景视野跨度

const cA = (a) => Math.pow(a, P.ED);
const cR = (rKm) => Math.pow(rKm / EARTH_RADIUS_KM, P.ER);
const diaFrac = (rKm) => P.BASE * cR(rKm);
const worldR = (rKm, span) => (diaFrac(rKm) * span) / 2;

/** 近观相机距离：d = 2·直径 / tan(FOV/2)，使行星恰好占画面高度的 1/4 */
function closeDistance(rKm) {
  const dia = 2 * worldR(rKm, DEF);
  return (2 * dia) / Math.tan((FOV_DEG * Math.PI) / 180 / 2);
}

function hexToRgba(hex, alpha) {
  const h = hex.replace('#', '');
  const full = h.length === 3 ? h[0] + h[0] + h[1] + h[1] + h[2] + h[2] : h;
  const n = parseInt(full, 16);
  return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + alpha + ')';
}

/* ============================================================
   程序化行星贴图（等距圆柱投影）。只用 c1/c2/rough，无需任何图片素材。
   ============================================================ */
function makePlanetTexture(THREE, p) {
  const W = 1024, H = 512;
  const cv = document.createElement('canvas');
  cv.width = W; cv.height = H;
  const g = cv.getContext('2d');

  let seed = p.id.split('').reduce((a, c) => a + c.charCodeAt(0), 7);
  const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };

  const base = g.createLinearGradient(0, 0, 0, H);
  base.addColorStop(0, p.c2);
  base.addColorStop(0.5, p.c1);
  base.addColorStop(1, p.c2);
  g.fillStyle = base;
  g.fillRect(0, 0, W, H);

  if (p.rough < 0.5) {
    // 气态巨行星：湍流条纹。用两组正弦叠加做出域扭曲感
    const bands = 30 + Math.floor(rnd() * 18);
    for (let i = 0; i < bands; i++) {
      const y = rnd() * H;
      const h = 3 + rnd() * (H / bands) * 2.1;
      const amp = 6 + rnd() * 22;
      g.beginPath();
      for (let x = 0; x <= W; x += 8) {
        const yy = y + Math.sin((x / W) * Math.PI * 2 * (1 + rnd() * 0.02) + i) * amp * 0.35;
        if (x === 0) g.moveTo(x, yy); else g.lineTo(x, yy);
      }
      g.lineWidth = h;
      g.strokeStyle = rnd() > 0.5
        ? hexToRgba(p.c1, 0.18 + rnd() * 0.3)
        : hexToRgba(p.c2, 0.16 + rnd() * 0.3);
      g.stroke();
    }
    if (p.id === 'jupiter') {
      // 大红斑
      g.save();
      g.translate(W * 0.66, H * 0.62);
      g.rotate(-0.12);
      g.beginPath();
      g.ellipse(0, 0, 82, 44, 0, 0, Math.PI * 2);
      const spot = g.createRadialGradient(0, 0, 4, 0, 0, 82);
      spot.addColorStop(0, '#d9613a');
      spot.addColorStop(0.62, '#b8452a');
      spot.addColorStop(1, 'rgba(150,60,40,0)');
      g.fillStyle = spot;
      g.fill();
      g.restore();
    }
  }

  if (p.rough > 0.5) {
    // 岩石行星：大尺度斑块 + 分形起伏
    for (let i = 0; i < 140; i++) {
      const x = rnd() * W, y = rnd() * H, r = 8 + rnd() * 70;
      g.fillStyle = rnd() > 0.5
        ? hexToRgba(p.c2, 0.1 + rnd() * 0.2)
        : hexToRgba('#ffffff', 0.04 + rnd() * 0.1);
      g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
    }
    if (p.rough > 0.8) {
      // 环形山（水星、火星）
      for (let i = 0; i < 110; i++) {
        const x = rnd() * W, y = rnd() * H, r = 2 + rnd() * 13;
        g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2);
        g.fillStyle = hexToRgba('#000000', 0.17); g.fill();
        g.beginPath(); g.arc(x - r * 0.25, y - r * 0.25, r * 0.72, 0, Math.PI * 2);
        g.fillStyle = hexToRgba('#ffffff', 0.17); g.fill();
      }
    }
  }

  if (p.id === 'earth') {
    // 陆地与云
    g.fillStyle = 'rgba(66,124,78,0.88)';
    [[0.14, 0.34, 78, 52], [0.19, 0.62, 54, 70], [0.48, 0.28, 96, 46],
     [0.53, 0.60, 62, 74], [0.80, 0.34, 82, 54], [0.87, 0.66, 48, 42]]
      .forEach((b) => {
        g.beginPath(); g.ellipse(b[0] * W, b[1] * H, b[2], b[3], 0, 0, Math.PI * 2); g.fill();
      });
    g.fillStyle = 'rgba(255,255,255,0.16)';
    for (let i = 0; i < 60; i++) {
      g.beginPath();
      g.ellipse(rnd() * W, rnd() * H, 20 + rnd() * 60, 8 + rnd() * 18, rnd() * 0.6, 0, Math.PI * 2);
      g.fill();
    }
  }

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  tex.wrapS = THREE.RepeatWrapping;
  return tex;
}

function makePlanetMaterial(THREE, p, tex) {
  return new THREE.MeshStandardMaterial({
    map: tex,
    roughness: Math.max(0.45, p.rough * 0.85),
    metalness: 0.06,
    bumpMap: tex,
    bumpScale: p.rough > 0.5 ? 0.45 : 0.06
  });
}

/* ============================================================
   星空：球面均匀分布 + 色温着色 + 银河带
   ============================================================ */
function kelvinToRGB(kelvin) {
  // 黑体色温的常用近似（Tanner Helland 拟合），返回线性 0..1
  const t = Math.max(1000, Math.min(40000, kelvin)) / 100;
  let r, g, b;
  if (t <= 66) {
    r = 255;
    g = 99.4708025861 * Math.log(t) - 161.1195681661;
    b = t <= 19 ? 0 : 138.5177312231 * Math.log(t - 10) - 305.0447927307;
  } else {
    r = 329.698727446 * Math.pow(t - 60, -0.1332047592);
    g = 288.1221695283 * Math.pow(t - 60, -0.0755148492);
    b = 255;
  }
  const cl = (v) => Math.max(0, Math.min(255, v)) / 255;
  // 转到近似线性空间，方便后续做物理亮度叠加
  return [Math.pow(cl(r), 2.2), Math.pow(cl(g), 2.2), Math.pow(cl(b), 2.2)];
}

function buildStarGeometry(THREE) {
  const n = STAR_COUNT + BAND_COUNT;
  const pos = new Float32Array(n * 3);
  const col = new Float32Array(n * 3);
  const size = new Float32Array(n);
  const bright = new Float32Array(n);
  const p = new THREE.Vector3();
  const bandNormal = new THREE.Vector3(0.42, 0.74, -0.52).normalize();
  // 预先算好从 (0,1,0) 转到银河带法向的旋转，避免每颗星都新建一个四元数
  const bandQ = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), bandNormal);

  let seed = 20261013;
  const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };

  for (let i = 0; i < n; i++) {
    const inBand = i >= STAR_COUNT;
    if (inBand) {
      // 银河带：沿一个大圆聚集，纬度方向用近似高斯衰减
      const lon = rnd() * Math.PI * 2;
      const lat = (rnd() + rnd() + rnd() - 1.5) * 0.22;
      const cosLat = Math.cos(lat);
      p.set(Math.cos(lon) * cosLat, Math.sin(lat), Math.sin(lon) * cosLat);
      p.applyQuaternion(bandQ);
    } else {
      const u = rnd() * 2 - 1;
      const phi = rnd() * Math.PI * 2;
      const s = Math.sqrt(Math.max(0, 1 - u * u));
      p.set(s * Math.cos(phi), s * Math.sin(phi), u);
    }
    const L = p.length() || 1;
    pos[i * 3] = (p.x / L) * SKY_RADIUS;
    pos[i * 3 + 1] = (p.y / L) * SKY_RADIUS;
    pos[i * 3 + 2] = (p.z / L) * SKY_RADIUS;

    // 色温分布：偏向冷色，少量红巨星
    const roll = rnd();
    const K = roll < 0.02 ? 2800 + rnd() * 900
      : roll < 0.2 ? 3400 + rnd() * 1600
      : roll < 0.78 ? 5200 + rnd() * 2800
      : 9000 + rnd() * 16000;
    const c = kelvinToRGB(K);
    col[i * 3] = c[0]; col[i * 3 + 1] = c[1]; col[i * 3 + 2] = c[2];

    // 亮度：幂律分布，少数亮星
    const mag = Math.pow(rnd(), 3.2);
    bright[i] = (inBand ? 0.34 : 1.0) * (0.18 + mag * 1.9);
    size[i] = (inBand ? 0.7 : 1.0) * (0.85 + mag * 2.3);
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('aColor', new THREE.BufferAttribute(col, 3));
  geo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
  geo.setAttribute('aBright', new THREE.BufferAttribute(bright, 1));
  return geo;
}

/* ============================================================
   主程序
   ============================================================ */
let THREE;
async function boot() {
  try {
    THREE = await import(THREE_CDN);
  } catch (err) {
    el.boot.classList.add('is-error');
    el.boot.querySelector('.boot__inner').innerHTML =
      '无法载入 three.js（CDN 不可达）。<br>本页需要网络访问 cdn.jsdelivr.net。<br><br>' +
      '<span style="opacity:.7">' + String(err && err.message || err) + '</span>';
    return;
  }
  try {
    start();
  } catch (err) {
    el.boot.classList.add('is-error');
    el.boot.querySelector('.boot__inner').innerHTML =
      '初始化失败：<br>' + String(err && err.message || err);
    console.error(err);
  }
}

function start() {
  /* ---------- 渲染器 ---------- */
  const renderer = new THREE.WebGLRenderer({
    canvas: el.gl, antialias: true, alpha: false, powerPreference: 'high-performance'
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(window.innerWidth, window.innerHeight, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  // 关键：关闭渲染器自带的 tone mapping。场景先渲染到线性 HDR 目标，
  // 由后处理统一做 ACES，否则星空与主场景会经历两次不同的映射。
  renderer.toneMapping = THREE.NoToneMapping;
  renderer.setClearColor(0x000000, 0);

  /* ---------- 主场景 ---------- */
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(FOV_DEG, window.innerWidth / window.innerHeight, 0.01, 5000);
  camera.up.set(0, 1, 0);
  camera.position.set(0, 7.0, 20);
  camera.lookAt(0, 0, 0);

  scene.add(new THREE.AmbientLight(0xffffff, 0.16));
  const sunLight = new THREE.PointLight(0xfff2d8, 3.0, 0, 0);
  sunLight.position.set(0, 0, 0);
  scene.add(sunLight);

  /* ---------- 太阳 ---------- */
  // 太阳不参与幂律（它是光源），用固定的视野占比，保证明显是主角
  const SUN_FRAC = 0.045;
  const SUN_FRAC_RATIO = SUN_FRAC / P.BASE; // 相对"地球占比"的倍数
  const sunTex = makePlanetTexture(THREE, {
    id: 'sun', c1: '#fff6d0', c2: '#ff9a2e', rough: 0.35
  });
  const sunMat = new THREE.MeshBasicMaterial({ map: sunTex });
  const sunMesh = new THREE.Mesh(new THREE.SphereGeometry(1, 64, 48), sunMat);
  scene.add(sunMesh);
  const sunGlow = new THREE.Mesh(
    new THREE.SphereGeometry(1, 32, 24),
    new THREE.MeshBasicMaterial({
      color: 0xffb457, transparent: true, opacity: 0.14,
      blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.BackSide
    })
  );
  scene.add(sunGlow);

  /* ---------- 行星 ---------- */
  const byId = {};
  PLANETS.forEach((p) => { byId[p.id] = p; });

  const bodies = ORBITS.map((o) => {
    const meta = byId[o.id];
    const tex = makePlanetTexture(THREE, meta);
    const mat = makePlanetMaterial(THREE, meta, tex);
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 64, 48), mat);
    mesh.userData.tex = tex;
    scene.add(mesh);

    // 轨道线
    const pts = [];
    const inc = o.incDeg * Math.PI / 180;
    const SEG = 320;
    for (let i = 0; i <= SEG; i++) {
      const nu = (i / SEG) * Math.PI * 2;
      const rReal = (o.a * (1 - o.e * o.e)) / (1 + o.e * Math.cos(nu));
      const rr = cA(rReal);
      const flat = rr * Math.sin(nu);
      pts.push(new THREE.Vector3(rr * Math.cos(nu), flat * Math.sin(inc), flat * Math.cos(inc)));
    }
    const lineGeo = new THREE.BufferGeometry().setFromPoints(pts);
    const lineMat = new THREE.LineBasicMaterial({
      color: new THREE.Color(meta.c1).multiplyScalar(0.5),
      transparent: true, opacity: 0.3
    });
    const line = new THREE.Line(lineGeo, lineMat);
    scene.add(line);

    // DOM 标签
    const label = document.createElement('div');
    label.className = 'label';
    label.innerHTML = '<span class="label__zh"></span><span class="label__en"></span>';
    label.querySelector('.label__zh').textContent = meta.nameZh;
    label.querySelector('.label__en').textContent = meta.nameEn;
    label.addEventListener('click', (e) => { e.stopPropagation(); selectPlanet(o.id); });
    el.labels.appendChild(label);

    return { o, meta, mesh, line, label, pos: new THREE.Vector3() };
  });

  /* ---------- 星空场景（独立 scene，便于相机置于原点）---------- */
  const skyScene = new THREE.Scene();
  const starGeo = buildStarGeometry(THREE);
  const starUniforms = {
    uBeta: { value: 0 },
    uPixelScale: { value: 1 },
    uSizeScale: { value: 1 }
  };
  const starMat = new THREE.ShaderMaterial({
    uniforms: starUniforms,
    transparent: true,
    depthTest: false,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: `
      attribute vec3 aColor;
      attribute float aSize;
      attribute float aBright;
      uniform float uPixelScale;
      uniform float uSizeScale;
      varying vec3 vColor;
      varying float vBright;
      void main() {
        vColor = aColor;
        vBright = aBright;
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_Position = projectionMatrix * mv;
        gl_PointSize = max(1.0, aSize * uSizeScale * uPixelScale / max(0.0001, -mv.z));
      }
    `,
    fragmentShader: `
      precision highp float;
      varying vec3 vColor;
      varying float vBright;
      void main() {
        vec2 d = gl_PointCoord - 0.5;
        float r2 = dot(d, d);
        if (r2 > 0.25) discard;
        float core = smoothstep(0.25, 0.0, r2);
        gl_FragColor = vec4(vColor * vBright * core, core * vBright);
      }
    `
  });
  const starPoints = new THREE.Points(starGeo, starMat);
  starPoints.frustumCulled = false;
  skyScene.add(starPoints);

  // HDR 渲染目标需要能渲染到半浮点纹理。若显卡/驱动不支持，整条管线会静默变黑，
  // 因此这里主动检测并降级到 8 位（视觉略差但不会黑屏）。
  const glCtx = renderer.getContext();
  const canHalfFloat = !!(glCtx.getExtension('EXT_color_buffer_half_float') ||
    glCtx.getExtension('EXT_color_buffer_float') ||
    (typeof glCtx.getExtension === 'function' && glCtx instanceof WebGL2RenderingContext &&
      glCtx.getExtension('EXT_color_buffer_float')));
  const RT_TYPE = canHalfFloat ? THREE.HalfFloatType : THREE.UnsignedByteType;
  console.log('[solar] 渲染目标类型 =', canHalfFloat ? 'HalfFloat (HDR)' : 'UnsignedByte (降级)');

  const cubeRT = new THREE.WebGLCubeRenderTarget(CUBE_FACE, {
    format: THREE.RGBAFormat,
    type: RT_TYPE,
    generateMipmaps: true,
    minFilter: THREE.LinearMipmapLinearFilter
  });
  cubeRT.texture.colorSpace = THREE.LinearSRGBColorSpace;
  const cubeCam = new THREE.CubeCamera(0.1, 2000, cubeRT);
  cubeCam.position.set(0, 0, 0); // 必须固定在原点
  skyScene.add(cubeCam);

  /* ---------- 屏幕渲染目标（存主场景，背景全透明）---------- */
  const screenRT = new THREE.WebGLRenderTarget(1, 1, {
    format: THREE.RGBAFormat,
    type: RT_TYPE,
    minFilter: THREE.LinearFilter,
    magFilter: THREE.LinearFilter,
    depthBuffer: true
  });
  screenRT.texture.colorSpace = THREE.LinearSRGBColorSpace;

  /* ---------- 后处理：逆光行差 + 多普勒 + ACES ---------- */
  const postScene = new THREE.Scene();
  const postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  const postUniforms = {
    tScene: { value: screenRT.texture },
    tSky: { value: cubeRT.texture },
    uBeta: { value: 0 },
    uHasRel: { value: 1 },
    uSkyInvRot: { value: new THREE.Matrix3() },
    uSunViewDir: { value: new THREE.Vector3(0, 0, -1) },
    uTanHalfFov: { value: Math.tan((FOV_DEG * Math.PI) / 180 / 2) },
    uAspect: { value: 1 },
    uExposure: { value: 1.0 },
    uSceneOnly: { value: 0 }
  };
  const postMat = new THREE.ShaderMaterial({
    uniforms: postUniforms,
    depthTest: false,
    depthWrite: false,
    vertexShader: `
      varying vec2 vUv;
      void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
    `,
    fragmentShader: `
      precision highp float;
      varying vec2 vUv;
      uniform sampler2D tScene;
      uniform samplerCube tSky;
      uniform float uBeta;
      uniform float uHasRel;
      uniform mat3  uSkyInvRot;
      uniform vec3  uSunViewDir;
      uniform float uTanHalfFov;
      uniform float uAspect;
      uniform float uExposure;
      uniform float uSceneOnly;

      float dopplerF(float cosT, float b) {
        float g = 1.0 / sqrt(max(1e-6, 1.0 - b * b));
        return 1.0 / (g * (1.0 - b * cosT));
      }

      // 黑体色温近似（与 JS 侧 kelvinToRGB 同源），返回 0..1 近似线性
      vec3 kelvin(float k) {
        float t = clamp(k, 1000.0, 40000.0) / 100.0;
        float r, g, b;
        if (t <= 66.0) {
          r = 255.0;
          g = 99.4708025861 * log(t) - 161.1195681661;
          b = (t <= 19.0) ? 0.0 : 138.5177312231 * log(t - 10.0) - 305.0447927307;
        } else {
          r = 329.698727446 * pow(t - 60.0, -0.1332047592);
          g = 288.1221695283 * pow(t - 60.0, -0.0755148492);
          b = 255.0;
        }
        return vec3(clamp(r,0.0,255.0), clamp(g,0.0,255.0), clamp(b,0.0,255.0)) / 255.0;
      }

      vec3 aces(vec3 x) {
        return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
      }

      void main() {
        vec4 scene = texture2D(tScene, vUv);
        vec3 color;

        // 调试：只看主场景（跳过星空与相对论）
        if (uSceneOnly > 0.5) {
          gl_FragColor = vec4(pow(aces(scene.rgb * uExposure), vec3(1.0 / 2.2)), 1.0);
          return;
        }

        if (uHasRel < 0.5) {
          // 对照组：无相对论
          color = textureCube(tSky, uSkyInvRot * vec3(0.0, 0.0, -1.0)).rgb * (1.0 - scene.a) + scene.rgb;
        } else {
          // 1) 从屏幕像素重建相机系光线方向。
          //    必须带上 tan(FOV/2) 与宽高比！直接 normalize(vec3(ndc,-1)) 得到的是
          //    一个 90° 锥，而相机是 30°——那会让每个像素的角度都算错。
          vec2 ndc = vec2(vUv.x * 2.0 - 1.0, vUv.y * 2.0 - 1.0);
          vec3 d = normalize(vec3(ndc.x * uAspect * uTanHalfFov, ndc.y * uTanHalfFov, -1.0));
          // 2) 逆光行差 → 星空系方向（屏幕像素 → 应采样的天区）
          float cosT = clamp(d.z, -1.0, 1.0);
          float cosSrc = clamp((cosT - uBeta) / max(1e-6, 1.0 - uBeta * cosT), -1.0, 1.0);
          vec3 dSrc = normalize(vec3(d.xy, cosSrc));
          // 3) 采样星空，并施加多普勒调色
          vec3 sky = textureCube(tSky, uSkyInvRot * dSrc).rgb;
          float D = dopplerF(cosT, uBeta);
          vec3 tint = kelvin(5800.0 * D) / max(1e-4, kelvin(5800.0));
          sky *= pow(D, 4.0) * tint;
          // 行星同理（有限距离，只做多普勒调色，不做光行差）
          float cosSun = clamp(dot(d, uSunViewDir), -1.0, 1.0);
          float Dp = dopplerF(cosSun, uBeta);
          vec3 tintP = kelvin(5800.0 * Dp) / max(1e-4, kelvin(5800.0));
          vec3 planet = scene.rgb * pow(Dp, 4.0) * tintP;
          color = sky * (1.0 - scene.a) + planet;
        }

        gl_FragColor = vec4(pow(aces(color * uExposure), vec3(1.0 / 2.2)), 1.0);
      }
    `
  });
  const postQuad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), postMat);
  postQuad.frustumCulled = false;
  postScene.add(postQuad);

  /* ============================================================
     像素回读遥测：把"黑屏"定位到具体哪一级
     ------------------------------------------------------------
     在控制台打印三件事，用于区分四种故障：
       skyMax > 0  且  planetAlpha > 0  → 管线正常，问题在后期合成
       skyMax == 0                      → 星空没渲染进立方体贴图
       planetAlpha == 0                 → 主场景没渲染出行星（几何/材质/相机问题）
       抛异常                           → 该渲染目标不可回读（格式问题）
     ============================================================ */
  function readTargetStats(target, face) {
    try {
      const w = target.width, h = target.height;
      const px = new Uint8Array(w * h * 4);
      if (face === undefined) renderer.readRenderTargetPixels(target, 0, 0, w, h, px);
      else renderer.readRenderTargetPixels(target, 0, 0, w, h, px, face);
      let maxR = 0, maxA = 0, nonZero = 0;
      for (let i = 0; i < px.length; i += 4) {
        maxR = Math.max(maxR, px[i], px[i + 1], px[i + 2]);
        maxA = Math.max(maxA, px[i + 3]);
        if (px[i] || px[i + 1] || px[i + 2]) nonZero++;
      }
      return { ok: true, maxR, maxA, nonZero, total: w * h };
    } catch (e) {
      return { ok: false, err: String(e && e.message || e) };
    }
  }

  let diagFrames = 0;
  function diagnostics() {
    // 每 120 帧打一次，避免刷屏；也可用 ?debug=diag 强制打开
    diagFrames++;
    if (!DEBUG.any && diagFrames % 120 !== 0) return;
    const skyPx = readTargetStats(cubeRT, 0);
    const scrPx = readTargetStats(screenRT);
    const line = (n, o) => o.ok
      ? `${n}: ok  maxRGB=${o.maxR}  maxAlpha=${o.maxA}  非零像素=${o.nonZero}/${o.total}`
      : `${n}: 回读失败 → ${o.err}`;
    console.log(
      '[solar diag]\n  ' + line('立方体贴图(face0,星空)', skyPx) +
      '\n  ' + line('屏幕目标(主场景)', scrPx) +
      `\n  β=${state.beta.toFixed(4)}  span=${state.span.toFixed(3)}  selected=${state.selected}` +
      `\n  camera=(${camera.position.x.toFixed(3)}, ${camera.position.y.toFixed(3)}, ${camera.position.z.toFixed(3)})` +
      `  near=${camera.near.toExponential(2)}  far=${camera.far.toFixed(0)}` +
      `\n  行星世界半径=${worldR(EARTH_RADIUS_KM, state.span).toExponential(3)}  星空半径=${SKY_RADIUS}`
    );
  }

  /* ============================================================
     状态与相机编排
     ============================================================ */
  const state = {
    span: DEF,
    spanTarget: DEF,
    az: 0.35,          // 方位角
    el: 20 * Math.PI / 180, // 俯角（真实八行星倾角均 < 3.4°，正视图会退化成一条线）
    selected: null,
    flying: false,
    flyT: 0,
    flyFrom: { pos: new THREE.Vector3(), quat: new THREE.Quaternion() },
    beta: 0,
    simTime: 0,
    lastReal: 0,
    tau: 0
  };

  const flyTo = { pos: new THREE.Vector3(), quat: new THREE.Quaternion() };
  const tmpV = new THREE.Vector3();
  const tmpV2 = new THREE.Vector3();
  const tmpQ = new THREE.Quaternion();
  const tmpM = new THREE.Matrix4();
  // 复用的临时对象（热路径里绝不 new，否则每帧产生大量垃圾）
  const tmpLook = new THREE.Matrix4();
  const tmpUp = new THREE.Vector3(0, 1, 0);
  const tmpOrigin = new THREE.Vector3(0, 0, 0);
  const tmpProj = new THREE.Vector3();

  /** 由方位角/俯角/跨度求相机位置与朝向（看向原点） */
  function overviewCam(span, az, el2, out) {
    const dist = (span / 2) / Math.tan((FOV_DEG * Math.PI) / 180 / 2);
    const ce = Math.cos(el2);
    out.pos.set(
      dist * ce * Math.cos(az),
      dist * Math.sin(el2),
      dist * ce * Math.sin(az)
    );
    tmpLook.lookAt(out.pos, tmpOrigin, tmpUp);
    out.quat.setFromRotationMatrix(tmpLook);
    return dist;
  }

  function selectPlanet(id) {
    if (state.flying) return;
    const b = bodies.find((x) => x.o.id === id);
    if (!b) return;
    state.selected = id;
    el.selcard.hidden = false;
    el.selZh.textContent = b.meta.nameZh;
    el.selEn.textContent = b.meta.nameEn;
    el.selTag.textContent = b.meta.tagline;
    el.selLink.href = '../index.html#/p/' + id;
    bodies.forEach((x) => x.label.classList.toggle('is-active', x.o.id === id));

    // 记录起点
    state.flyFrom.pos.copy(camera.position);
    state.flyFrom.quat.copy(camera.quaternion);
    state.flying = true;
    state.flyT = 0;
    state.tau = 0;
    el.gl.classList.add('is-flying');
    el.hint.classList.add('is-hidden');
  }

  function clearSelection() {
    state.selected = null;
    el.selcard.hidden = true;
    bodies.forEach((x) => x.label.classList.remove('is-active'));
  }

  /** 计算抵达某行星时的相机位置与朝向 */
  function arrivalFor(b) {
    const d = closeDistance(b.o.radiusKm);
    const center = b.pos;
    // 从当前相机方向的反侧靠近，避免穿太阳
    tmpV.copy(camera.position).sub(center);
    if (tmpV.lengthSq() < 1e-12) tmpV.set(1, 0.3, 0.6);
    tmpV.normalize();
    flyTo.pos.copy(center).addScaledVector(tmpV, d);
    // 略微抬高，视线带一点俯角
    flyTo.pos.y += d * 0.12;
    tmpLook.lookAt(flyTo.pos, center, tmpUp);
    flyTo.quat.setFromRotationMatrix(tmpLook);
  }

  /* ============================================================
     交互
     ============================================================ */
  let drag = null;
  el.gl.addEventListener('pointerdown', (e) => {
    if (state.flying) return;
    drag = { x: e.clientX, y: e.clientY, az: state.az, el: state.el };
    el.gl.setPointerCapture && el.gl.setPointerCapture(e.pointerId);
  });
  el.gl.addEventListener('pointermove', (e) => {
    if (!drag || state.flying) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    state.az = drag.az - dx * 0.004;
    state.el = Math.max(-1.45, Math.min(1.45, drag.el + dy * 0.004));
  });
  const endDrag = () => { drag = null; };
  el.gl.addEventListener('pointerup', endDrag);
  el.gl.addEventListener('pointercancel', endDrag);
  el.gl.addEventListener('pointerleave', endDrag);

  el.gl.addEventListener('wheel', (e) => {
    if (state.flying) return;
    e.preventDefault();
    const k = Math.exp(e.deltaY * 0.0012);
    state.spanTarget = Math.max(DEF * 0.06, Math.min(FULL * 1.6, state.spanTarget * k));
  }, { passive: false });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      state.flying = false;
      el.gl.classList.remove('is-flying');
      state.span = DEF;
      state.spanTarget = DEF;
      state.az = 0.35;
      state.el = 20 * Math.PI / 180;
      clearSelection();
    } else if (e.key === 'h' || e.key === 'H') {
      el.panel.hidden = !el.panel.hidden;
    }
  });

  /* ============================================================
     面板绑定
     ============================================================ */
  const bind = (id, key, fmt, after) => {
    const r = document.getElementById('r-' + id);
    const v = document.getElementById('v-' + id);
    if (!r) return;
    r.addEventListener('input', () => {
      P[key] = parseFloat(r.value);
      if (v) v.textContent = fmt(P[key]);
      if (after) after();
    });
  };
  bind('duration', 'duration', (v) => v.toFixed(0));
  bind('beta', 'betaPeak', (v) => v.toFixed(3));
  bind('ed', 'ED', (v) => v.toFixed(2), () => {
    FULL; // 跨度依赖 ED，下一帧会重算
    state.spanTarget = Math.min(state.spanTarget, 2 * cA(30.06992) * 1.6 + 8);
  });
  bind('er', 'ER', (v) => v.toFixed(2));
  bind('base', 'BASE', (v) => v.toFixed(3));
  document.getElementById('c-aberr').addEventListener('change', (e) => {
    P.relativity = e.target.checked;
  });
  document.getElementById('btn-more').addEventListener('click', () => { el.panel.hidden = !el.panel.hidden; });
  document.getElementById('btn-close-panel').addEventListener('click', () => { el.panel.hidden = true; });

  // HUD 里显示物理最短时间
  const tripMin = minTripSeconds((cA(30.06992) - cA(1)) * AU);
  const vTrip = document.getElementById('v-tripmin');
  if (vTrip) vTrip.textContent = (tripMin / 60).toFixed(2);
  el.hudNote.textContent = 'β 为演示参数。真实航程 4.4836 AU，一程物理最短 ' +
    (tripMin / 60).toFixed(2) + ' 分钟。';

  /* ============================================================
     尺寸与渲染循环
     ============================================================ */
  function resize() {
    const w = window.innerWidth, h = window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    const dpr = renderer.getPixelRatio();
    screenRT.setSize(Math.floor(w * dpr), Math.floor(h * dpr));
    starUniforms.uPixelScale.value = (h * dpr) / (2 * Math.tan((FOV_DEG * Math.PI) / 180 / 2));
    starUniforms.uSizeScale.value = dpr;
    // 后处理重建光线需要同样的宽高比，否则光行差角度会算错
    postUniforms.uAspect.value = w / h;
  }
  window.addEventListener('resize', resize);
  resize();

  const invRot = new THREE.Matrix3();
  const sunWorld = new THREE.Vector3(0, 0, 0);

  function frame(now) {
    requestAnimationFrame(frame);
    const dtReal = state.lastReal ? Math.min(0.1, (now - state.lastReal) / 1000) : 0;
    state.lastReal = now;

    // 模拟时间推进（真实开普勒周期 + 单一全局倍率）
    state.simTime += dtReal * TIME_SCALE;

    // 行星尺寸随视野跨度变化 → 每帧更新
    const spanNow = state.span;
    bodies.forEach((b) => {
      const pos = positionAtRuntime(b.o, state.simTime);
      b.pos.copy(pos);
      b.mesh.position.copy(pos);
      b.mesh.scale.setScalar(worldR(b.o.radiusKm, spanNow));
      b.mesh.rotation.y += dtReal * 0.12;
    });
    const sunR = worldR(SUN_RADIUS_KM, spanNow) * (SUN_FRAC_RATIO);
    sunMesh.scale.setScalar(sunR);
    sunGlow.scale.setScalar(sunR * 1.35);

    // 相机
    if (state.flying && state.selected) {
      const b = bodies.find((x) => x.o.id === state.selected);
      if (b) {
        state.flyT += dtReal;
        const u = Math.min(1, state.flyT / P.duration);
        // 位置：缓入缓出
        const e = u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2;
        arrivalFor(b); // 每帧重算（行星在动）
        tmpV.copy(state.flyFrom.pos).lerp(flyTo.pos, e);
        camera.position.copy(tmpV);
        // 朝向：四元数 slerp，避免万向节问题
        camera.quaternion.copy(state.flyFrom.quat).slerp(flyTo.quat, e);
        state.beta = displayBetaAt(u, P.betaPeak);
        state.tau += dtReal / Math.max(1e-6, lorentzGamma(state.beta));
        if (u >= 1) {
          state.flying = false;
          el.gl.classList.remove('is-flying');
        }
      }
    } else {
      state.beta += (0 - state.beta) * Math.min(1, dtReal * 4);
      // 环绕太阳
      state.span += (state.spanTarget - state.span) * Math.min(1, dtReal * 6);
      const cam = { pos: tmpV2, quat: tmpQ };
      overviewCam(state.span, state.az, state.el, cam);
      if (state.selected) {
        // 停留：绕选中行星缓慢漂移
        const b = bodies.find((x) => x.o.id === state.selected);
        if (b) {
          const d = closeDistance(b.o.radiusKm);
          state.az += dtReal * 0.06;
          const ce = Math.cos(state.el * 0.5);
          cam.pos.set(
            b.pos.x + d * ce * Math.cos(state.az),
            b.pos.y + d * Math.sin(state.el * 0.5),
            b.pos.z + d * ce * Math.sin(state.az)
          );
          tmpLook.lookAt(cam.pos, b.pos, tmpUp);
          cam.quat.setFromRotationMatrix(tmpLook);
        }
      }
      camera.position.copy(cam.pos);
      camera.quaternion.copy(cam.quat);
    }

    // 动态近远平面：跨度巨大，固定 near/far 必然 z-fighting
    let target = null;
    if (state.selected) target = bodies.find((x) => x.o.id === state.selected).pos;
    const dist = target ? camera.position.distanceTo(target) : camera.position.length();
    camera.near = Math.max(1e-5, dist * 1e-4);
    camera.far = Math.max(SKY_RADIUS * 4, dist * 60);
    camera.updateProjectionMatrix();

    /* ---------- 1. Sky pass：立方体相机置于原点，只复制旋转 ---------- */
    if (!DEBUG.nosky) {
      cubeCam.quaternion.copy(camera.quaternion);
      cubeCam.position.set(0, 0, 0);
      cubeCam.update(renderer, skyScene);
    }

    /* ---------- 2. Scene pass：主场景渲染到屏幕目标，背景全透明 ---------- */
    // 调试模式下给个深蓝底，便于区分"没渲染出来"与"渲染成黑色"
    renderer.setRenderTarget(screenRT);
    renderer.setClearColor(DEBUG.any ? 0x101a3a : 0x000000, 1);
    renderer.clear(true, true, true);
    if (!DEBUG.skyonly) renderer.render(scene, camera);
    renderer.setRenderTarget(null);

    /* ---------- 3. 后处理 ---------- */
    // 调试：nopost 让后处理只输出主场景，用于确认"主场景本身是否渲染正常"
    postUniforms.uSceneOnly.value = DEBUG.nopost ? 1 : 0;
    // 星空方向需要从世界系变换到相机系：用世界旋转矩阵的逆
    tmpM.makeRotationFromQuaternion(camera.quaternion);
    invRot.setFromMatrix4(tmpM).invert();
    postUniforms.uSkyInvRot.value.copy(invRot);
    postUniforms.uBeta.value = (P.relativity && !DEBUG.beta0) ? clampBeta(state.beta) : 0;
    postUniforms.uHasRel.value = (P.relativity && !DEBUG.beta0) ? 1 : 0;
    postUniforms.uExposure.value = DEBUG.raw ? 40 : 1.0;
    // 太阳方向（相机系）
    tmpV.copy(sunWorld).sub(camera.position).normalize().applyQuaternion(
      tmpQ.copy(camera.quaternion).invert()
    );
    postUniforms.uSunViewDir.value.copy(tmpV);
    starUniforms.uBeta.value = postUniforms.uBeta.value;

    renderer.render(postScene, postCam);

    updateLabels(spanNow);
    updateHud();
    diagnostics();
  }

  /** 运行时位置（使用面板可调的 ED） */
  function positionAtRuntime(o, tSim) {
    const TWO_PI = Math.PI * 2;
    const M = o.phaseDeg * Math.PI / 180 + (TWO_PI * tSim) / (o.period * 86400);
    const E = solveKepler(M, o.e);
    const u = o.a * (Math.cos(E) - o.e);
    const v = o.a * Math.sqrt(1 - o.e * o.e) * Math.sin(E);
    const rReal = Math.hypot(u, v);
    const rDisp = cA(rReal);
    const cosNu = rReal > 0 ? u / rReal : 1;
    const sinNu = rReal > 0 ? v / rReal : 0;
    const inc = o.incDeg * Math.PI / 180;
    const flat = rDisp * sinNu;
    return new THREE.Vector3(rDisp * cosNu, flat * Math.sin(inc), flat * Math.cos(inc));
  }

  /* ============================================================
     标签投影（每帧）
     ============================================================ */
  function updateLabels(spanNow) {
    const w = window.innerWidth, h = window.innerHeight;
    const v = tmpProj;
    const tanHalf = Math.tan(FOV_DEG * Math.PI / 180 / 2);
    bodies.forEach((b) => {
      v.copy(b.pos).project(camera);
      // z 越界或 w<0 表示在相机背后，必须隐藏，否则标签会飞到画面另一侧
      if (v.z > 1 || v.z < -1) { b.label.style.display = 'none'; return; }
      b.label.style.display = '';
      b.label.style.left = ((v.x * 0.5 + 0.5) * w) + 'px';
      b.label.style.top = ((-v.y * 0.5 + 0.5) * h) + 'px';
      // 远处缩成光点，避免标签糊成一片
      const px = (2 * worldR(b.o.radiusKm, spanNow) /
        (2 * Math.max(1e-6, camera.position.distanceTo(b.pos)) * tanHalf)) * h;
      b.label.classList.toggle('is-far', px < 26);
      b.line.material.opacity = state.selected === b.o.id ? 0.7 : 0.28;
    });
  }

  function updateHud() {
    const b = state.beta;
    el.hudBeta.textContent = b.toFixed(4);
    el.hudGamma.textContent = lorentzGamma(b).toFixed(3);
    el.hudTau.textContent = state.tau.toFixed(1) + ' s';
    el.hudDop.textContent = doppler(1, b).toFixed(3) + '×';
  }

  /* ---------- 启动 ---------- */
  if (DEBUG.any) {
    el.hint.innerHTML = '调试模式：<b>' + DEBUG.label + '</b> · 去掉 ?debug= 恢复正常';
    el.hint.classList.remove('is-hidden');
    console.log('[solar] debug flags =', DEBUG);
  }
  el.boot.classList.add('is-hidden');
  if (!DEBUG.any) setTimeout(() => el.hint.classList.add('is-hidden'), 9000);
  requestAnimationFrame(frame);
}

boot();
