/* shader 数学验证 —— node shader.check.mjs
 *
 * 后处理是整页最难验证的部分：它跑在 GPU 上，我无法在本地看到结果。
 * 因此把 GLSL 里的逐行数学用 JS 复刻一遍，检查三件事：
 *   1. 屏幕像素 → 相机系方向，是否与透视投影的实际光线一致
 *   2. 逆光行差后，采样方向是否始终落在立方体贴图能覆盖的范围内（防黑边）
 *   3. 多普勒调色的数值是否落在 tone mapping 能吃下的范围（防过曝 / 防 NaN）
 */
import { doppler, unaberrateCos, clampBeta, BETA_MAX_SAFE } from './rel.js';
import { FOV_DEG } from './solarsystem.js';

let fail = 0, count = 0;
const t = (ok, msg) => { count++; if (!ok) fail++; console.log((ok ? '  PASS  ' : '  FAIL  ') + msg); };
const sec = (n) => console.log('\n── ' + n + ' ──');
const f = (n, d = 4) => (n == null || !Number.isFinite(n) ? String(n) : n.toFixed(d));
const DEG = Math.PI / 180;

/* GLSL 复刻：片段着色器里的方向构造（必须带 tan(FOV/2) 与宽高比） */
const TAN_HALF = Math.tan(FOV_DEG * DEG / 2);
function shaderRay(uvx, uvy, aspect) {
  const nx = uvx * 2 - 1, ny = uvy * 2 - 1;
  const x = nx * aspect * TAN_HALF, y = ny * TAN_HALF, z = -1;
  const L = Math.hypot(x, y, z);
  return [x / L, y / L, z / L];
}
/* 修复前的写法，用于存档对比 */
function shaderRayBuggy(uvx, uvy) {
  const x = uvx * 2 - 1, y = uvy * 2 - 1, z = -1;
  const L = Math.hypot(x, y, z);
  return [x / L, y / L, z / L];
}

sec('1. shader 方向 vs 透视相机实际光线');
const tanHalf = TAN_HALF;
for (const aspect of [1.0, 16 / 9, 21 / 9, 0.6]) {
  let worst = 0;
  for (const nx of [-1, -0.5, 0, 0.37, 1]) {
    for (const ny of [-1, -0.3, 0, 0.72, 1]) {
      const uvx = (nx + 1) / 2, uvy = (ny + 1) / 2;
      const s = shaderRay(uvx, uvy, aspect);
      const r = [nx * tanHalf * aspect, ny * tanHalf, -1];
      const rl = Math.hypot(r[0], r[1], r[2]);
      const rn = [r[0] / rl, r[1] / rl, r[2] / rl];
      const dot = s[0] * rn[0] + s[1] * rn[1] + s[2] * rn[2];
      worst = Math.max(worst, Math.acos(Math.max(-1, Math.min(1, dot))) / DEG);
    }
  }
  t(worst < 1e-4, `宽高比 ${aspect}: 修正后 shader 方向与真实光线最大夹角 ${worst.toExponential(1)}°（数值舍入内一致）`);
}
// 存档：修复前的写法错得有多离谱
{
  const s = shaderRayBuggy(1, 1), r = shaderRay(1, 1, 16 / 9);
  const dot = s[0] * r[0] + s[1] * r[1] + s[2] * r[2];
  const err = Math.acos(Math.max(-1, Math.min(1, dot))) / DEG;
  t(err > 20, `反例存档：修复前角点方向偏差 ${f(err, 1)}°（90° 锥 vs 30° 视场）—— 这正是数值验证抓到的 bug`);
}
// 屏幕角点相对光轴的夹角只由 FOV 决定，与宽高比无关
{
  const c1 = Math.acos(-shaderRay(1, 1, 1)[2]) / DEG;
  const c2 = Math.acos(-shaderRay(1, 1, 16 / 9)[2]) / DEG;
  t(c2 > c1, `屏幕角点张角随宽高比增大：1:1 → ${f(c1, 2)}°，16:9 → ${f(c2, 2)}°`);
  t(Math.abs(c1 - Math.atan(Math.tan(15 * DEG) * Math.SQRT2) / DEG) < 1e-9,
    `1:1 时角点张角 = atan(√2·tan(FOV/2)) = ${f(c1, 3)}°（解析核对）`);
}

sec('2. 逆光行差后采样方向必须落在立方体贴图覆盖范围内');
// CubeCamera 内部 fov 固定 90°，6 面无缝覆盖整个球面 → 任何方向都可采样。
// 但要确认：源方向不会退化成 NaN，且确实与屏幕像素一一对应。
for (const beta of [0, 0.5, 0.9, 0.98, 0.995]) {
  let maxSrc = 0, minCos = 1, bad = 0;
  for (let i = 0; i <= 32; i++) {
    for (let j = 0; j <= 32; j++) {
      const s = shaderRay(i / 32, j / 32, 16 / 9);
      const cosT = Math.max(-1, Math.min(1, s[2]));
      const cosSrc = unaberrateCos(cosT, beta);
      if (!Number.isFinite(cosSrc)) bad++;
      minCos = Math.min(minCos, cosSrc);
      maxSrc = Math.max(maxSrc, Math.acos(Math.max(-1, Math.min(1, cosSrc))) / DEG);
    }
  }
  t(bad === 0, `β=${beta}: 33×33 像素网格无 NaN（最大源方向 ${f(maxSrc, 2)}°）`);
  t(minCos >= -1 && minCos <= 1, `β=${beta}: 源方向余弦 ∈ [${f(minCos, 4)}, 1] 未越界`);
}
// 关键：源方向角必须 < 90°（落在立方体贴图某个面内）
const cornerSrc = (() => {
  const s = shaderRay(1, 1, 16 / 9);
  return Math.acos(Math.max(-1, Math.min(1, unaberrateCos(s[2], 0.98)))) / DEG;
})();
t(cornerSrc > 90, `β=0.98 屏幕角点源方向 ${f(cornerSrc, 2)}° > 90° → 前向视锥不够，必须全方向立方体贴图`);
t(cornerSrc < 180, `且 < 180° → 立方体贴图必然完备，无黑边`);

sec('3. 多普勒调色的数值范围');
const kelvin = (k) => {
  const tt = Math.max(1000, Math.min(40000, k)) / 100;
  let r, g, b;
  if (tt <= 66) {
    r = 255; g = 99.4708025861 * Math.log(tt) - 161.1195681661;
    b = tt <= 19 ? 0 : 138.5177312231 * Math.log(tt - 10) - 305.0447927307;
  } else {
    r = 329.698727446 * Math.pow(tt - 60, -0.1332047592);
    g = 288.1221695283 * Math.pow(tt - 60, -0.0755148492);
    b = 255;
  }
  const c = (v) => Math.max(0, Math.min(255, v)) / 255;
  return [c(r), c(g), c(b)];
};
const baseK = kelvin(5800);
for (const beta of [0, 0.5, 0.98]) {
  for (const cosT of [-1, -0.5, 0, 0.5, 1]) {
    const D = doppler(cosT, beta);
    const gain = Math.pow(D, 4);
    const tint = kelvin(5800 * D).map((v, i) => v / Math.max(1e-4, baseK[i]));
    const ok = Number.isFinite(gain) && gain > 0 && tint.every((v) => Number.isFinite(v) && v >= 0 && v < 1e6);
    t(ok, `β=${beta} cosθ=${cosT}: D=${f(D, 3)} 增益=${gain.toExponential(2)} 色调=[${tint.map((v) => f(v, 2)).join(', ')}]`);
  }
}
// ACES 在极端输入下是否饱和而不产生 NaN
const aces = (x) => Math.max(0, Math.min(1, (x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14)));
const maxGain = Math.pow(doppler(1, 0.98), 4);
t(Number.isFinite(aces(maxGain)), `ACES 对最大增益 ${maxGain.toExponential(2)} 输出 ${f(aces(maxGain), 6)}（饱和到 1，无 NaN）`);
t(aces(0) === 0, 'ACES(0) = 0');
t(Math.abs(aces(maxGain) - 1) < 1e-6, '前向过曝被 ACES 压到 1.0（这正是需要 tone mapping 的原因）');
// 后向是否被压得过暗
const minGain = Math.pow(doppler(-1, 0.98), 4);
t(minGain < 1e-3 && aces(minGain * 3) < 0.05, `后向增益 ${minGain.toExponential(2)} → ACES 后 ${f(aces(minGain * 3), 5)}（暗淡，符合预期）`);

sec('4. 合成公式：alpha 遮罩');
// color = sky·(1−a) + planet
for (const [a, sky, planet, want] of [
  [0, 1, 0, 1], [1, 1, 0.5, 0.5], [0.5, 1, 0, 0.5], [0, 0, 0, 0]
]) {
  const got = sky * (1 - a) + planet;
  t(Math.abs(got - want) < 1e-12, `a=${a} sky=${sky} planet=${planet} → ${f(got, 3)} = 期望 ${want}`);
}
t(true, '背景像素 (a=0) 完全显示星空；行星像素 (a=1) 完全显示行星');

sec('5. β 钳制在 shader 入口');
// shader 里用 max(1e-6, 1.0 - b*b)，但 β 本身也应已钳制
t(clampBeta(1) < 1, `clampBeta(1) = ${f(clampBeta(1), 12)} < 1 → gamma 不会为 Infinity`);
t(clampBeta(2) === BETA_MAX_SAFE, 'clampBeta 对超限输入生效');
const bMax = clampBeta(1);
t(Number.isFinite(doppler(1, bMax)) && Number.isFinite(doppler(-1, bMax)),
  `β 取钳制上限时前后多普勒均有限（${doppler(1, bMax).toExponential(2)} / ${doppler(-1, bMax).toExponential(2)}）`);

sec('6. 星空着色器的实际用法：星方向 → 所见方向（正向压缩）');
// 着色器对 8000 颗星逐个施加 aberrateCos，必须真的把星空压向运动方向
import { aberrateCos } from './rel.js';
for (const beta of [0.5, 0.9, 0.98]) {
  // 均匀分布的方向，施加后落到前方锥内的比例必须大幅上升
  let before = 0, after = 0, n = 0;
  for (let i = 0; i < 20000; i++) {
    const u = -1 + (2 * (i + 0.5)) / 20000;
    const c = Math.cos(60 * DEG);          // 前方 60° 锥的判据 cos
    if (u > c) before++;
    if (aberrateCos(u, beta) > c) after++;
    n++;
  }
  const f0 = before / n, f1 = after / n;
  t(f1 >= f0 * 1.9, `β=${beta}: 前方 60° 锥内星占比 ${f(f0 * 100, 1)}% → ${f(f1 * 100, 1)}%（星空明显向前聚集）`);
}
// 端点不变：正前方与正后方的星方向不被移动
for (const beta of [0.5, 0.98]) {
  t(Math.abs(aberrateCos(1, beta) - 1) < 1e-12, `β=${beta}: 正前方星方向不动`);
  t(Math.abs(aberrateCos(-1, beta) + 1) < 1e-12, `β=${beta}: 正后方星方向不动`);
}

console.log('\n' + (fail === 0 ? `✅ 全部通过（${count} 项断言）` : `❌ 失败 ${fail} / ${count} 项`));
process.exit(fail === 0 ? 0 : 1);
