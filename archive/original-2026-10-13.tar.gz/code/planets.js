/* 星际探索局 — 行星数据（唯一事实源）
 *
 * 这份文件同时服务两个目标：
 *   1. 浏览器原型 prototype/index.html  —— 通过 <script type="module"> 导入
 *   2. 小程序 data/planets.js            —— 通过 CommonJS require 使用
 * 因此只导出纯数据，不含任何 DOM / 样式 / 平台 API。
 *
 * 字段说明：
 *   id          路由参数（?id=mars），一旦定下不要再改
 *   nameZh/En   中英文名称
 *   tagline     首页卡牌上的一句话介绍
 *   c1/c2       球体双色（c1 亮部受光面，c2 暗部），CSS 与 three.js 共用
 *   rough       表面粗糙度，用于生成程序化贴图（0 光滑如气态，1 粗糙如岩石）
 *   facts       基本数据；各行星条数可不同，阅读页用 wx:for / forEach 渲染
 *   paragraphs  2—3 段科普介绍
 *
 * 排序：由离太阳由近及远（水星 → 海王星），无例外。
 */
export const PLANETS = [
  {
    id: 'mercury',
    nameZh: '水星',
    nameEn: 'Mercury',
    tagline: '离太阳最近、跑得最快的行星',
    c1: '#c9cdd6',
    c2: '#6b7280',
    rough: 0.95,
    facts: [
      { label: '太阳系排位', value: '第 1 颗' },
      { label: '直径', value: '4,879 公里' },
      { label: '距离太阳', value: '0.39 倍地日距离' },
      { label: '一天', value: '约 59 地球日' },
      { label: '一年', value: '88 地球日' },
      { label: '卫星', value: '没有' }
    ],
    paragraphs: [
      '水星是太阳系里最小、也是离太阳最近的行星。因为离得太近，它被太阳的引力牢牢抓住，跑得比其他任何行星都快——绕太阳一圈只要 88 个地球日。',
      '它的表面布满密密麻麻的环形山，看起来和月球很像。这里几乎没有大气，白天被太阳晒到 400 摄氏度以上，夜里又降到零下 170 摄氏度左右，是太阳系里昼夜温差最大的地方。'
    ]
  },
  {
    id: 'venus',
    nameZh: '金星',
    nameEn: 'Venus',
    tagline: '太阳系最热的行星，也是夜空中最亮的星',
    c1: '#f5e2b0',
    c2: '#b07d3a',
    rough: 0.4,
    facts: [
      { label: '太阳系排位', value: '第 2 颗' },
      { label: '直径', value: '12,104 公里' },
      { label: '距离太阳', value: '0.72 倍地日距离' },
      { label: '一天', value: '约 243 地球日' },
      { label: '一年', value: '225 地球日' },
      { label: '表面温度', value: '约 465 摄氏度' },
      { label: '卫星', value: '没有' }
    ],
    paragraphs: [
      '金星和地球大小差不多，常被叫作"地球的姊妹星"。它裹着一层厚厚的二氧化碳大气，云层里还含有硫酸，把太阳的热量牢牢锁在里面。',
      '所以它虽然比水星离太阳更远，表面却比水星更热，平均温度超过 460 摄氏度，足以熔化铅。它还是我们夜空中除了月亮之外最亮的天体，就是常说的"启明星"和"长庚星"。'
    ]
  },
  {
    id: 'earth',
    nameZh: '地球',
    nameEn: 'Earth',
    tagline: '目前已知唯一有生命的蓝色星球',
    c1: '#79b8f0',
    c2: '#1b4f8a',
    rough: 0.65,
    facts: [
      { label: '太阳系排位', value: '第 3 颗' },
      { label: '直径', value: '12,742 公里' },
      { label: '距离太阳', value: '1 倍地日距离' },
      { label: '一天', value: '约 24 小时' },
      { label: '一年', value: '365.25 天' },
      { label: '卫星', value: '1 颗（月球）' }
    ],
    paragraphs: [
      '地球是太阳系里唯一表面有大量液态水的行星，也是目前已知唯一有生命存在的地方。',
      '恰到好处的日照距离让水能以液态存在，大气层则帮我们挡住了大部分有害辐射和小陨石。地球只有一颗卫星——月球，它相对地球来说大得少见，也稳定着地球的自转。'
    ]
  },
  {
    id: 'mars',
    nameZh: '火星',
    nameEn: 'Mars',
    tagline: '红色的沙漠世界，人类最想登陆的行星',
    c1: '#e0764a',
    c2: '#7a2f1c',
    rough: 0.9,
    facts: [
      { label: '太阳系排位', value: '第 4 颗' },
      { label: '直径', value: '6,779 公里' },
      { label: '距离太阳', value: '1.52 倍地日距离' },
      { label: '一天', value: '约 24.6 小时' },
      { label: '一年', value: '687 地球日' },
      { label: '卫星', value: '2 颗' }
    ],
    paragraphs: [
      '火星表面覆盖着大量含铁的尘土，氧化后呈现红色，所以被称为"红色星球"。',
      '这里的气候又冷又干，却有着太阳系里最高的火山——奥林帕斯山，高度超过 21 公里，差不多是珠穆朗玛峰的两倍多。它是目前人类探测器去得最多、也最有可能留下脚印的行星。'
    ]
  },
  {
    id: 'jupiter',
    nameZh: '木星',
    nameEn: 'Jupiter',
    tagline: '太阳系最大的行星，一个巨大的气态球',
    c1: '#e8d2ae',
    c2: '#a9713f',
    rough: 0.35,
    facts: [
      { label: '太阳系排位', value: '第 5 颗' },
      { label: '直径', value: '139,820 公里' },
      { label: '距离太阳', value: '5.20 倍地日距离' },
      { label: '一天', value: '约 9.9 小时' },
      { label: '一年', value: '约 11.9 地球年' },
      { label: '卫星', value: '95 颗以上' }
    ],
    paragraphs: [
      '木星大得能装下 1300 多个地球。它主要由氢和氦组成，没有可以站立的固体表面，只有越往深处越浓密的气体。',
      '木星转得非常快，一天还不到 10 小时，飞快的自转把云层拉成了一条条彩色条纹。条纹中那个显眼的"大红斑"是一个巨大的风暴，已经持续了至少几百年。'
    ]
  },
  {
    id: 'saturn',
    nameZh: '土星',
    nameEn: 'Saturn',
    tagline: '戴着光环的宝石，太阳系最上镜的行星',
    c1: '#f0e0b6',
    c2: '#b39257',
    rough: 0.3,
    facts: [
      { label: '太阳系排位', value: '第 6 颗' },
      { label: '直径', value: '116,460 公里' },
      { label: '距离太阳', value: '9.58 倍地日距离' },
      { label: '一天', value: '约 10.7 小时' },
      { label: '一年', value: '约 29.5 地球年' },
      { label: '卫星', value: '146 颗以上' },
      { label: '光环', value: '主要成分是冰块' }
    ],
    paragraphs: [
      '土星最让人记住的就是那圈漂亮的光环。光环由无数大小不一的冰块和岩石碎屑组成，从远处看就像一条平滑的丝带。',
      '和木星一样，土星也是主要由气体构成的巨行星，密度小得惊人——如果有一个足够大的水池，土星能浮在水面上。它拥有的卫星数量在太阳系里是最多的。'
    ]
  },
  {
    id: 'uranus',
    nameZh: '天王星',
    nameEn: 'Uranus',
    tagline: '躺着自转的冰蓝色行星',
    c1: '#bfeef0',
    c2: '#3f8f9e',
    rough: 0.25,
    facts: [
      { label: '太阳系排位', value: '第 7 颗' },
      { label: '直径', value: '50,724 公里' },
      { label: '距离太阳', value: '19.2 倍地日距离' },
      { label: '一天', value: '约 17.2 小时' },
      { label: '一年', value: '约 84 地球年' },
      { label: '卫星', value: '28 颗以上' }
    ],
    paragraphs: [
      '天王星是一颗冰巨星，大气里的甲烷会吸收红光，所以它呈现出淡淡的青蓝色。',
      '它最特别的地方是"躺着"转：自转轴几乎和公转平面平行，倾斜超过 90 度。这可能是很久以前被一个巨大的天体撞出来的，结果就是它的两极会各自迎来长达 42 年的白天和黑夜。'
    ]
  },
  {
    id: 'neptune',
    nameZh: '海王星',
    nameEn: 'Neptune',
    tagline: '最遥远的深蓝行星，风速快得吓人',
    c1: '#6f9df0',
    c2: '#1f3f9e',
    rough: 0.25,
    facts: [
      { label: '太阳系排位', value: '第 8 颗' },
      { label: '直径', value: '49,244 公里' },
      { label: '距离太阳', value: '30.07 倍地日距离' },
      { label: '一天', value: '约 16.1 小时' },
      { label: '一年', value: '约 165 地球年' },
      { label: '卫星', value: '16 颗以上' }
    ],
    paragraphs: [
      '海王星是离太阳最远的行星，也是肉眼完全看不到的一颗。它是先被数学家"算"出来、然后才被望远镜找到的行星。',
      '这里又暗又冷，却刮着太阳系里最猛的风，风速可以超过每小时 2000 公里。它绕太阳一圈要 165 个地球年——从被发现到现在，它才刚走完一圈多一点。'
    ]
  }
]

/* 便于小程序侧 require 时取用（浏览器里 typeof module === 'undefined'，不会执行） */
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PLANETS }
}
