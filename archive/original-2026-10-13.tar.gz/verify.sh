#!/usr/bin/env bash
# 一键跑全部测试。无需安装任何依赖，只要有 node。
#
#   bash verify.sh
#
# 三套测试共 384 项断言：
#   rel.test.mjs     177  狭义相对论核心（零依赖纯函数）
#   orbit.test.mjs   154  轨道根数、开普勒、幂律压缩与显示尺度
#   shader.check.mjs  53  GLSL 逐行数学的 JS 复刻

set -u
cd "$(dirname "$0")/code/solar" || exit 1

BOLD=$'\033[1m'; DIM=$'\033[2m'; RED=$'\033[31m'; GRN=$'\033[32m'; OFF=$'\033[0m'
TOTAL=0; FAILED=0

if ! command -v node >/dev/null 2>&1; then
  echo "${RED}找不到 node。请先安装 Node.js（本项目开发时用 v26.3.0）。${OFF}"
  exit 1
fi

echo "${BOLD}═══ 语法检查 ═══${OFF}"
for f in ../app.js solarsystem.js solar-app.js rel.js; do
  printf '  %-18s ' "$f"
  if node --check "$f" 2>/dev/null; then
    echo "${GRN}OK${OFF}"
  else
    echo "${RED}语法错误${OFF}"; FAILED=$((FAILED+1))
  fi
done

echo
echo "${BOLD}═══ 测试套件 ═══${OFF}"
for f in rel.test.mjs orbit.test.mjs shader.check.mjs; do
  printf '  %-18s ' "$f"
  OUT=$(node "$f" 2>/dev/null)
  if [ $? -eq 0 ]; then
    N=$(echo "$OUT" | tail -1 | grep -o '[0-9]\+' | head -1)
    echo "${GRN}✅ 通过${OFF} ${DIM}(${N} 项断言)${OFF}"
    TOTAL=$((TOTAL + ${N:-0}))
  else
    echo "${RED}❌ 失败${OFF}"
    echo "$OUT" | grep -E '^\s+FAIL' | sed 's/^/      /'
    FAILED=$((FAILED+1))
  fi
done

echo
if [ "$FAILED" -eq 0 ]; then
  echo "${GRN}${BOLD}✅ 全部通过（${TOTAL} 项断言）${OFF}"
  echo
  echo "${DIM}注意：本脚本只验证数值正确性，不验证画面。"
  echo "渲染效果需在浏览器中人工确认（详见 HANDOFF.md）。${OFF}"
  echo
  echo "启动本地服务预览："
  echo "  cd code && python3 -m http.server 8010"
  echo "  然后打开 http://127.0.0.1:8010/index.html"
  exit 0
else
  echo "${RED}${BOLD}❌ 有 ${FAILED} 项检查未通过${OFF}"
  exit 1
fi
